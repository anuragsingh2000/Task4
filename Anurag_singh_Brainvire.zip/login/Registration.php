<html>  
<head>  
    <title>user registration</title>  
    <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>  

<style>
 body{   
    background-color : grey;  
}  
.h1{  
    border: solid gray 1px;  
    width:25%;  
    border-radius: 2px;  
    margin: 120px auto;  
    background: white;  
    padding: 50px;  
}  
.label{  
    font color: red;  
    background: #337ab7;  
    padding: 7px;  
    margin-left: 70%;  
}  

.pi {  
 

    background-color: grey;  
}  

form {  
    padding-top: 10px;  
    font-size: 14px;  
    margin-top: 30px;  
    color: black;
}  
.card-title {   
font-weight: 300;  
color: blue;
 }  




</style>

<body class = "pi" >   
        <h1>Please register here</h1>  
        <form  action = "Registration.php" method = "POST" enctype="multipart/form-data" >  
            <p>  
                <label class = "card-title"> Full_Name</label>  
                <input type = "text"  name  = "Full_Name" />  
            </p>  
            <p>  
                <label class = "card-title"> Email_Address </label>  
                <input type = "email" name  = "Email_Address" />  
            </p>  

            <p>  
                <label class = "card-title"> Password </label>  
                <input type = "password" name  = "Password" />  
            </p>  
          
            <p>  
                <label class = "card-title"> C_password </label>  
                <input type = "password" name  = "C_password" />  
            </p>  
          
            <p>  
                <label class = "card-title"> Address </label>  
                <input type = "text" name  = "Address" />  
            </p>  
            <select>
    <option>Select user type</option>
    <?php 
    $connection = mysqli_connect('localhost', 'root', 'root','userdata');
    $query ="SELECT * FROM access_type";
    $result = mysqli_query($connection,$query);
        while($row = mysqli_fetch_assoc($result)){
        $id =$row['type'];
      echo "<option value='$id'>$id</option>";
    ?>
   <?php
        }    
    ?>

</select>         
          
            <p>     
            <input type="submit" value="submit" name="submit">
            </p>  
        </form>  
    </div>  
    
</body>     
</html>  

<?php

 $connection = mysqli_connect('localhost','root','root','userdata');

if(isset($_POST['submit'])){

    $Full_Name = $_POST['Full_Name'];
    $Email_Address = $_POST['Email_Address'];
    $Password = $_POST['Password'];
    $C_password = $_POST['C_password'];
    $Address = $_POST['Address'];
    $access_type = $_POST['type'];

    if($Password == $C_password){

    $query = "INSERT INTO  candidate_info (Full_Name, Email_Address , Password, C_password, Address) 
    VALUES ('$Full_Name','$Email_Address','$Password','$C_password','$Address')";
    $result = mysqli_query($connection, $query);
     
    $user_id = mysqli_insert_id($connection);
    $query1 = "SELECT id FROM access_type WHERE type = $access_type";
$result5 = mysqli_query($connection,$query1);
// echo "$access_id";
$row = mysqli_fetch_assoc($result5);
$access_type = $row['id'];
// print_r($access_type);
//echo $access_type;
$user_table = "INSERT INTO user_type (`user_id`, `user_access_type`) 
VALUES ( '$user_id', '$access_type')";
mysqli_query($connection,$user_table);


    //print_r($result);
    if(!$result){
        echo "Data is not updated" . mysqli_error($connection);
    }else{
        echo "Data is updated";
    }
}else{
    echo "Incorrect credentials! ";
}

}

?>