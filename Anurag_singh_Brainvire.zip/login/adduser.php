<html>  
<head>  
    <title>user registration</title>  
    <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>  

<style>
 body{   
    background: #eee;  
}  
.form{  
    border: solid gray 1px;  
    width:25%;  
    border-radius: 2px;  
    margin: 120px auto;  
    background: white;  
    padding: 50px;  
}  
#input{  
    color: #fff;  
    background: #337ab7;  
    padding: 7px;  
    margin-left: 70%;  
}  


</style>

<body>    
        <h1>Please register here</h1>  
        <form  action = "Registration.php" method = "POST" enctype="multipart/form-data" >  
            <p>  
                <label> Full_Name</label>  
                <input type = "text"  name  = "Full_Name" />  
            </p>  
            <p>  
                <label> Email_Address </label>  
                <input type = "email" name  = "Email_Address" />  
            </p>  

            <p>  
                <label> Password </label>  
                <input type = "password" name  = "Password" />  
            </p>  
           
          
            <p>  
                <label> Address </label>  
                <input type = "text" name  = "Address" />  
            </p>  
            <select>
    <option>Select user type</option>
    <?php 
    $connection = mysqli_connect('localhost', 'root', 'root','userdata');
    $query = "SELECT * FROM access_type";

    $result = mysqli_query($connection,$query);
    print_r($result);
    if(!$result){
        die("Query Failed");
    }
    while($row = mysqli_fetch_assoc($result)){
        $type = $row['type'];
        echo "<option value='$type'>$type</option>";   
    
    }

   ?>

</select>            
          
            <p>     
            <input type="submit" value="submit" name="submit">
            </p>  
        </form>  
    </div>  
    
</body> 
</html>  

<?php

 $connection = mysqli_connect('localhost','root','root','userdata');
 
 if(isset($_POST['submit'])){
    
    $Full_Name = $_POST['Full_Name'];
    $Email_Address = $_POST['Email_Address'];
    $Password = $_POST['Password'];
    $Address = $_POST['Address'];

    if($Password){

    $query = "INSERT INTO  candidate_info (Full_Name, Email_Address , Password, Address) VALUES ('$Full_Name','$Email_Address','$Password','$Address')";
    $result = mysqli_query($connection, $query);
    print_r($result);
    if(!$result){
        echo "Data is not updated" . mysqli_error($connection);
    }else{
        echo "Data is updated";
    }
}else{
    echo "password and confirm password are not same please check it";
}

}




?>