
<?php

$connection = mysqli_connect('localhost','root','root','userdata');
if(!$connection){
    echo "Database connection failed";
}
$id = $_GET['id'];

$datafetch = "SELECT * FROM chapter where id=$id";
$result = mysqli_query($connection, $datafetch);
print_r($result);  
$data = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    
    $query = "UPDATE chapter SET name='$name' WHERE id='$id'";

    $result= mysqli_query($connection,$query);

    if(!$result){
        echo "something went wrong! chapter has not been updated!...";
    }else{
        echo "chapter has been successfully updated!...";
    }
}

?>
<html>
    <head>
        <title>Update</title>
    </head>
    <body>
    <form action="chapter_edit.php?id=<?php echo $id;?>" method="POST" enctype="multipart/form-data">

<h1>Edit the the existing chapter record!...</h1>

<tr>name</td>
<input type="text" value="<?php echo $row['name']?>" name="name">
         <input type="submit" name="submit">
        </form>
    </body>
</html>