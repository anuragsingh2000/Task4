<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User dashboard! </title>
</head>
<body>
<style>
    
a:link, a:visited {
  background-color: green;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: red;
}

.menu-icon {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            font-size: 24px;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 120px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-menu a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-menu a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-menu {
            display: block;
        }

</style>
<?php 
session_start();   
$connection = mysqli_connect('localhost', 'root', 'root', 'userdata');
$Email_Address = $_SESSION['Email_Address'];

// print_r($row);

if(!(isset($_SESSION['log'])) || $_SESSION['log'] !== true){

    header("Location: login.php");
    exit();
}
?>
<h3>Welcome <?php echo $_SESSION['Email_Address'];?> <?php echo $_SESSION['access_type'] ;?></h3>
<!-- <h1>WELCOME TO THE USER DASHBOARD!</h1> -->
<a href="adduser.php" target="_blank">Add user</a>

<!-- <a href="adduser.php">click here to add new user!</a></p> -->
<p><a href="subject.php">subject!</a></p>
<p><a href="standard.php">standard!</a></p>
<p><a href="chapter.php">chapter!</a></p>

<div class="dropdown">
        <span class="menu-icon" onclick="toggleDropdownMenu()">&#9776;</span>
        <!-- Dropdown menu -->
        <div class="dropdown-menu" id="myDropdown">
            <a href="assign_chapter.php">Assign Chapter</a>
            <a href="assign_subject.php">Assign Subject</a>
            <!-- Add more options as needed -->
        </div>

        <script>

function toggleDropdownMenu() {
            var dropdownMenu = document.getElementById("myDropdown");
            dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
        }
        </script>

<!-- <p><a href="assign_chapter.php">Assign_chapter!</a></p> -->
<!-- <p><a href="assign_subject.php">Assign_subject!</a></p> -->
<br>
<br>
<br>
<br>
<br>
<form action="view_login.php" method = "post " enctype = "multipart/form-data ">
<!-- <button name = "view">view</button> -->

<a href="view_login.php">view</a>
<button><a href = "logout.php">logout</a></button>
</form>
</body>
</html>