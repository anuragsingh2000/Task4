
<?php

$connection = mysqli_connect('localhost','root','root','userdata');
if(!$connection){
    echo "Database connection failed";
}
$id = $_GET['id'];


$datafetch = "SELECT * FROM candidate_info where id=$id";
$result = mysqli_query($connection, $datafetch);


    
$data = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update'])){
    $Full_Name = $_POST['Full_Name'];
    $Email_Address = $_POST['Email_Address'];
    $Password = $_POST['Password'];
    $Address = $_POST['Address'];
    
    $query = "UPDATE candidate_info SET Full_Name='$Full_Name',Email_Address='$Email_Address',Password='$Password',Address = '$Address' WHERE id='$id'";

    $result= mysqli_query($connection,$query);

    if(!$result){
        echo "something went wrong! data has not been updated!...";
    }else{
        echo "your data has been successfully updated!...";
    }
}

?>
<html>
    <head>
        <title>Update</title>
    </head>
    <body>
    <form action="edit_login.php?id=<?php echo $id;?>" method="post" enctype="multipart/form-data">

<h1>Edit the the existing user record!...</h1>

<tr><td class = "pi" > Full_Name</td>
<input type="text" value="<?php echo $row['Full_Name']?>" name="Full_Name">
<td class = "pi" >Email_Address</td>
<input type="email" value="<?php echo $row['Email_Address']?>" name="Email_Address">
<td class = "pi" >Password</td>
<input type="password" value="<?php echo $row['Password']?>" name="Password">
<td class = "pi" >Address</td>
<input type="text" value="<?php echo $row['Address']?>" name="Address">
         <input type="submit" value="update" name="update">
        </form>
    </body>
</html>

<?php 

?>