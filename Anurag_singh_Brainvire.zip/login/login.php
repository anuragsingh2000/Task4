<! DOCTYPE html>  
<html lang="en" >  
<head>  
  <meta charset="UTF-8">  
  <title> Welcome to Login Page 
 </title>  
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">  
</head>  
<style>  
html {   
    height: 100%;   
}  
body {   
    height: 100%;   
    background-color: purple;
}  
.global-container {  
    height: 100%;  
    display: flex;  
    align-items: center;  
    justify-content: center;  
    background-color: purple;  
}  
form {  
    padding-top: 10px;  
    font-size: 14px;  
    margin-top: 30px;  
    color: black;
}  
.card-title {   
font-weight: 300;  
color: blue;
 }  
.btn {  
    font-size: 14px;  
    margin-top: 20px;  
}  
.login-form {   
    width: 330px;  
    margin: 20px;  
    color:red;
}  
.sign-up {  
    text-align: center;  
    padding: 20px 0 0;  
}  
.alert {  
    margin-bottom: 0px;  
    font-size: 13px;  
    margin-top: 0px;  
}  
</style>  
<body>  
<div class="pt-5">  
  <div class="global-container">  
    <div class="card login-form">  
    <div class="card-body">  
        <h3 class="card-title text-center">PLEASE LOGIN </h3>  
        <div class="card-text">  
        <form action="login.php" method="POST" enctype="multipart/form-data"> 
                <div class="form-group">  
                    <label for="exampleInputEmail1"> Enter Email address </label>  
                    <input type="email" name = "Email_Address" class="form-control form-control-sm" id="exampleInputEmail1" aria-describedby="emailHelp">  
                </div>  
                <div class="form-group">  
                    <label for="exampleInputPassword1">Enter Password </label>    
                    <input type="password" name = "Password" class="form-control form-control-sm" id="exampleInputPassword1">  
                </div>  
                <button class="btn" name="login">Login</button>
        <p class="text">Don't have an account? <a href="Registration.php">Register</a></p> 
            </form>  
        </div>  
    </div>  
</div>  
</div>  
</body>  
</html>  

<?php
if(isset($_POST['login'])){

$connection = mysqli_connect('localhost','root','root','userdata');

$Email_Address = $_POST['Email_Address'];
$Password = $_POST['Password'];
$query = " SELECT * FROM candidate_info WHERE Email_Address = '$Email_Address' && Password = '$Password'";
$result = mysqli_query($connection,$query);

$row = mysqli_fetch_assoc($result);

if(count($row) > 0){
    session_start();
    $_SESSION['log'] = true;
    $_SESSION['Email_Address'] = $row['Email_Address'];
    $query1 = "SELECT  access_type.type AS access_type_name, candidate_info.*
FROM candidate_info  
INNER JOIN user_type ON candidate_info.id = user_type.user_id 
INNER JOIN access_type ON user_type.user_access_type = access_type.id 
WHERE candidate_info.Email_Address = '$Email_Address'";

$result1 = mysqli_query($connection, $query1);

$row = mysqli_fetch_assoc($result1);

$_SESSION['access_type'] = $row['access_type_name'];

 header('Location: dashboard.php'); 
}else{
  echo "Check Email id or Password";
}

}

?>
