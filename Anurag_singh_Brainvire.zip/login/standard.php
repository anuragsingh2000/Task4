
<?php

$connection = mysqli_connect('localhost','root','root','userdata');
$query = "SELECT * from standard";
$result = mysqli_query($connection,$query); 

if(mysqli_num_rows($result)>0){
    ?>
    <table align="center"border="1px" style="width:400px;
    padding:10px;">
    <tr>
        <th>id</th>   
        <th>class</th>
        <th>Action</th>
        
    </tr>
        <?php
        while($row = mysqli_fetch_assoc($result)){
            ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['class'];?></td>
            <td>
            <button><a href="standard_edit.php?id=<?php echo $row['id']?>">edit</a></button>
            <button><a href="standard_delete.php?delete=<?php echo $row['id'];?>">delete</a></button>
        </td>
        </tr>
        <?php 
        }
}

        ?>   

<br>
         
         <br><td> <br><p><a href="standard_add.php">Add standard!</a></p></td>

</table>
