<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add standard</title>
</head>
<body>
<form  action = "standard_add.php" method = "POST" enctype="multipart/form-data" >  
            <p>  
                <label class = "card-title"> class</label>  
                <input type = "text"  name  = "class" />  
            </p> 
            <p>     
            <input type="submit" value="submit" name="submit">
            </p>  
        </form>
</body>
</html>


<?php

 $connection = mysqli_connect('localhost','root','root','userdata');

if(isset($_POST['submit'])){

    $class = $_POST['class'];
  
  $query = "INSERT INTO  standard (class)  VALUES ('$class')";
  $result = mysqli_query($connection, $query);
 
  if(!$result){
    echo "standard has not been  updated" . mysqli_error($connection);
}else{
    echo "standard has been updated";
}
}

?>