
<?php

$connection = mysqli_connect('localhost','root','root','userdata');
if(!$connection){
    echo "Database connection failed";
}
$id = $_GET['id'];

$datafetch = "SELECT * FROM standard where id=$id";
$result = mysqli_query($connection, $datafetch);
print_r($result);  
$data = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);

if(isset($_POST['submit'])){
    $class = $_POST['class'];
    
    $query = "UPDATE standard SET class='$class' WHERE id='$id'";

    $result= mysqli_query($connection,$query);

    if(!$result){
        echo "something went wrong! data has not been updated!...";
    }else{
        echo "your data has been successfully updated!...";
    }
}

?>
<html>
    <head>
        <title>Update</title>
    </head>
    <body>
    <form action="standard_edit.php?id=<?php echo $id;?>" method="POST" enctype="multipart/form-data">

<h1>Edit the the existing subject record!...</h1>

<tr>class</td>
<input type="text" value="<?php echo $row['class']?>" name="class">
         <input type="submit" name="submit">
        </form>
    </body>
</html>