<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add subject</title>
</head>
<body>
<form  action = "subject_add.php" method = "POST" enctype="multipart/form-data" >  
            <p>  
                <label class = "card-title"> name</label>  
                <input type = "text"  name  = "name" />  
            </p> 
            <p>     
            <input type="submit" value="submit" name="submit">
            </p>  
        </form>
</body>
</html>


<?php

 $connection = mysqli_connect('localhost','root','root','userdata');

if(isset($_POST['submit'])){

    $name = $_POST['name'];
  
  $query = "INSERT INTO  subject (name)  VALUES ('$name')";
  $result = mysqli_query($connection, $query);
 
  if(!$result){
    echo "subject has not been  updated" . mysqli_error($connection);
}else{
    echo "subject has been updated";
}
}

?>