<?php

if(isset($_GET['delete'])){
    $connection = mysqli_connect('localhost','root','root','userdata');
    if(!$connection){
        echo "Database connection failed";
    }
    $id = $_GET['delete'];

    $query = "DELETE FROM subject where id = $id";

    $result = mysqli_query($connection,$query);
    
    if(!$result){
        echo " record has not been deleted";
}else{
    echo "Record has been deleted successfully";
}
}

?>