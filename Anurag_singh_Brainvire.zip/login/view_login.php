
<?php

$connection = mysqli_connect('localhost','root','root','userdata');
$query = "SELECT * from candidate_info";
$result = mysqli_query($connection,$query); 

if(mysqli_num_rows($result)>0){
    ?>
    <table align="center"border="1px" style="width:400px;
    padding:10px;">
    <tr>
        <th>id</th>   
        <th>Full_Name</th>
        <th>Email_Address</th>
        <th>Password</th>
        <th>Address</th>
        <th>action</th>
    </tr>
        <?php
        while($row = mysqli_fetch_assoc($result)){
            ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['Full_Name'];?></td>
            <td><?php echo $row['Email_Address'];?></td>
            <td><?php echo $row['Password'];?></td>
            <td><?php echo $row['Address'];?></td>
            <td>
            <button><a href="edit_login.php?id=<?php echo $row['id']?>">edit</a></button>
            <button><a href="delete_login.php?delete=<?php echo $row['id'];?>">delete</a></button>
            <button><a href="view_login.php">view</a></button>
        </td>
        </tr>
        <?php 
        }
}

        ?>         
</table>
<?php
        

?>
